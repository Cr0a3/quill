#include <iostream>
using namespace std;

int main(int argc, char* args[]) {
    cout << "Hello, World!";
    return 0;
}